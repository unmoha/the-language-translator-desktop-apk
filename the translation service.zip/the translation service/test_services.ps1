# Test script for translation services
Write-Host "Testing LibreTranslate on port 5000..."
try {
    $libreResult = Invoke-RestMethod -Uri 'http://localhost:5000/translate' -Method Post -ContentType 'application/x-www-form-urlencoded' -Body 'q=hello&source=en&target=fr&format=text' -TimeoutSec 10
    Write-Host "✅ LibreTranslate OK: $libreResult"
} catch {
    Write-Host "❌ LibreTranslate Error: $($_.Exception.Message)"
}

Write-Host "`nTesting Translation Service on port 8082..."
try {
    $serviceResult = Invoke-RestMethod -Uri 'http://localhost:8082/api/v1/translate/text' -Method Post -ContentType 'application/json' -Body '{"sourceText":"hello","sourceLang":"en","targetLang":"fr"}' -TimeoutSec 10
    Write-Host "✅ Translation Service OK: $($serviceResult.translatedText)"
} catch {
    Write-Host "❌ Translation Service Error: $($_.Exception.Message)"
}

Write-Host "`nChecking what's running on ports..."
try {
    $port5000 = Get-NetTCPConnection -LocalPort 5000 -ErrorAction SilentlyContinue
    Write-Host "Port 5000: $($port5000.State)"
} catch {
    Write-Host "Port 5000: Not listening"
}

try {
    $port8082 = Get-NetTCPConnection -LocalPort 8082 -ErrorAction SilentlyContinue
    Write-Host "Port 8082: $($port8082.State)"
} catch {
    Write-Host "Port 8082: Not listening"
}
