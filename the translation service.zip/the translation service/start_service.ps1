# Start Translation Service Script
Write-Host "=== Starting Translation Service ===" -ForegroundColor Green

cd "c:\Users\hp\OneDrive\Desktop\my transltion apk\translation-service"

Write-Host "🔧 Compiling..." -ForegroundColor Cyan
mvn clean compile

Write-Host "🚀 Starting service..." -ForegroundColor Cyan
mvn spring-boot:run

Write-Host "✅ Service started!" -ForegroundColor Green
