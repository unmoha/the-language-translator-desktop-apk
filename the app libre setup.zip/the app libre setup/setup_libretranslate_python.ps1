# LibreTranslate Python Setup Script
Write-Host "=== LibreTranslate Python Setup ===" -ForegroundColor Green

Write-Host "Setting up LibreTranslate with Python..." -ForegroundColor Cyan
try {
    # Check if Python is installed
    python --version | Out-Null
    Write-Host "Python found" -ForegroundColor Green
    
    # Install LibreTranslate
    Write-Host "Installing LibreTranslate..." -ForegroundColor Cyan
    pip install libretranslate
    
    # Start LibreTranslate
    Write-Host "Starting LibreTranslate..." -ForegroundColor Cyan
    Start-Process -WindowStyle Hidden -FilePath "python" -ArgumentList "-m", "libretranslate", "--host", "0.0.0.0", "--port", "5000"
    Write-Host "LibreTranslate starting on port 5000" -ForegroundColor Green
    Write-Host "Wait 30 seconds for startup..." -ForegroundColor Yellow
    Start-Sleep -Seconds 30
} catch {
    Write-Host "Python setup failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Please install Python from https://python.org" -ForegroundColor Yellow
    exit
}

# Test if LibreTranslate is running
Write-Host "Testing LibreTranslate API..." -ForegroundColor Cyan
try {
    $response = Invoke-RestMethod -Uri 'http://localhost:5000/languages' -Method Get -TimeoutSec 10
    Write-Host "LibreTranslate API is working" -ForegroundColor Green
    Write-Host "Available languages: $($response.Count)" -ForegroundColor Cyan
} catch {
    Write-Host "LibreTranslate API test failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Trying manual start..." -ForegroundColor Yellow
    
    # Try starting manually
    Start-Process -WindowStyle Normal -FilePath "python" -ArgumentList "-m", "libretranslate", "--host", "0.0.0.0", "--port", "5000"
    Write-Host "LibreTranslate started in new window" -ForegroundColor Green
    Write-Host "Wait 30 seconds then test again" -ForegroundColor Yellow
    Start-Sleep -Seconds 30
    
    try {
        $response = Invoke-RestMethod -Uri 'http://localhost:5000/languages' -Method Get -TimeoutSec 10
        Write-Host "LibreTranslate API is now working" -ForegroundColor Green
        Write-Host "Available languages: $($response.Count)" -ForegroundColor Cyan
    } catch {
        Write-Host "Still failed - please check manually" -ForegroundColor Red
        exit
    }
}

Write-Host "LibreTranslate setup complete" -ForegroundColor Green
Write-Host "API running on: http://localhost:5000" -ForegroundColor Cyan
Write-Host "Translation service will now use real API translations" -ForegroundColor Green
