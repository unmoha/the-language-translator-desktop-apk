# LibreTranslate Setup Script
Write-Host "=== LibreTranslate Setup ===" -ForegroundColor Green

# Check if Docker is available
try {
    docker --version | Out-Null
    Write-Host "✅ Docker found" -ForegroundColor Green
    $useDocker = $true
} catch {
    Write-Host "❌ Docker not found, will use Python" -ForegroundColor Yellow
    $useDocker = $false
}

if ($useDocker) {
    Write-Host "`n🐳 Starting LibreTranslate with Docker..." -ForegroundColor Cyan
    try {
        docker run -d -p 5000:5000 --name libretranslate libretranslate/libretranslate
        Write-Host "✅ LibreTranslate starting on port 5000" -ForegroundColor Green
        Write-Host "⏱️ Wait 30 seconds for startup..." -ForegroundColor Yellow
        Start-Sleep -Seconds 30
    } catch {
        Write-Host "❌ Docker failed: $($_.Exception.Message)" -ForegroundColor Red
        exit
    }
} else {
    Write-Host "`n🐍 Setting up LibreTranslate with Python..." -ForegroundColor Cyan
    try {
        # Check if Python is installed
        python --version | Out-Null
        Write-Host "✅ Python found" -ForegroundColor Green
        
        # Install LibreTranslate
        Write-Host "📦 Installing LibreTranslate..." -ForegroundColor Cyan
        pip install libretranslate
        
        # Start LibreTranslate
        Write-Host "🚀 Starting LibreTranslate..." -ForegroundColor Cyan
        Start-Process -WindowStyle Hidden -FilePath "python" -ArgumentList "-m", "libretranslate", "--host", "0.0.0.0", "--port", "5000"
        Write-Host "✅ LibreTranslate starting on port 5000" -ForegroundColor Green
        Write-Host "⏱️ Wait 30 seconds for startup..." -ForegroundColor Yellow
        Start-Sleep -Seconds 30
    } catch {
        Write-Host "❌ Python setup failed: $($_.Exception.Message)" -ForegroundColor Red
        exit
    }
}

# Test if LibreTranslate is running
Write-Host "`n🧪 Testing LibreTranslate API..." -ForegroundColor Cyan
try {
    $response = Invoke-RestMethod -Uri 'http://localhost:5000/languages' -Method Get -TimeoutSec 10
    Write-Host "✅ LibreTranslate API is working!" -ForegroundColor Green
    Write-Host "📚 Available languages: $($response.Count)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ LibreTranslate API test failed: $($_.Exception.Message)" -ForegroundColor Red
    exit
}

Write-Host "`n🎉 LibreTranslate setup complete!" -ForegroundColor Green
Write-Host "🌐 API running on: http://localhost:5000" -ForegroundColor Cyan
Write-Host "🔧 Translation service will now use real API translations!" -ForegroundColor Green
