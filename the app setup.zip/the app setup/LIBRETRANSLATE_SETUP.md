# LibreTranslate Setup Guide

## Option 1: Docker (Recommended)

1. **Install Docker** if not already installed
2. **Run LibreTranslate**:
   ```bash
   docker run -ti --rm -p 5000:5000 libretranslate/libretranslate
   ```
3. **Wait for startup** - you should see "Running on http://0.0.0.0:5000"

## Option 2: Python Installation

1. **Install LibreTranslate**:
   ```bash
   pip install libretranslate
   ```

2. **Run LibreTranslate**:
   ```bash
   libretranslate --host localhost --port 5000
   ```

## Option 3: Download Pre-built Binary

1. **Download** from https://github.com/LibreTranslate/LibreTranslate/releases
2. **Extract and run**:
   ```bash
   ./libretranslate.exe --host localhost --port 5000
   ```

## Verify Installation

Once LibreTranslate is running, test it:
```bash
curl http://localhost:5000/translate -X POST -d "q=hello&source=en&target=fr&format=text"
```

Expected response:
```json
{"translatedText":"Bonjour"}
```

## Configuration in Your Project

The translation service is configured to use `http://localhost:5000` by default. If you run LibreTranslate on a different port, update `application.properties`:

```properties
libretranslate.url=http://localhost:YOUR_PORT
```

## Language Support

LibreTranslate supports many languages including:
- English (en)
- Spanish (es) 
- French (fr)
- German (de)
- Italian (it)
- Portuguese (pt)
- Russian (ru)
- Chinese (zh)
- Arabic (ar)
- Japanese (ja)
- Korean (ko)
- And more...

## Fallback Behavior

If LibreTranslate is not available, the system will automatically fall back to the built-in dictionary for basic translations.
