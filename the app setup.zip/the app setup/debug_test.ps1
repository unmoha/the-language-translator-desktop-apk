# Debug test for translation service
Write-Host "=== Translation Service Debug Test ===" -ForegroundColor Green

Write-Host "`n1. Checking if port 8082 is listening..."
try {
    $port = Get-NetTCPConnection -LocalPort 8082 -ErrorAction SilentlyContinue
    if ($port) {
        Write-Host "✅ Port 8082 is listening (State: $($port.State))" -ForegroundColor Green
    } else {
        Write-Host "❌ Port 8082 is NOT listening" -ForegroundColor Red
        exit
    }
} catch {
    Write-Host "❌ Error checking port: $($_.Exception.Message)" -ForegroundColor Red
    exit
}

Write-Host "`n2. Testing basic HTTP connection..."
try {
    $response = Invoke-WebRequest -Uri 'http://localhost:8082/api/v1/translate' -Method GET -TimeoutSec 5
    Write-Host "✅ Basic HTTP connection works" -ForegroundColor Green
} catch {
    Write-Host "❌ HTTP connection failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n3. Testing translation endpoint..."
try {
    $body = '{"sourceText":"hello","sourceLang":"en","targetLang":"fr"}'
    $headers = @{'Content-Type'='application/json'}
    $response = Invoke-RestMethod -Uri 'http://localhost:8082/api/v1/translate/text' -Method Post -Headers $headers -Body $body -TimeoutSec 10
    Write-Host "✅ Translation endpoint works!" -ForegroundColor Green
    Write-Host "Response: $($response | ConvertTo-Json -Compress)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Translation endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        Write-Host "Status Code: $($_.Exception.Response.StatusCode.value__)" -ForegroundColor Yellow
        Write-Host "Response: $($_.Exception.Response.GetResponseStream() | Get-Content)" -ForegroundColor Yellow
    }
}

Write-Host "`n=== Debug Test Complete ===" -ForegroundColor Green
