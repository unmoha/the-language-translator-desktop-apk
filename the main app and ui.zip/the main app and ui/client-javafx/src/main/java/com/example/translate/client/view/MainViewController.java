package com.example.translate.client.view;

import com.example.translate.client.service.BackendTranslationClient;
import com.example.translate.client.viewmodel.TextTranslateViewModel;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.*;
import java.util.stream.Collectors;

public class MainViewController {

    @FXML private TextField serverUrlField;
    @FXML private ComboBox<String> sourceLangComboBox;
    @FXML private ComboBox<String> targetLangComboBox;
    @FXML private TextArea sourceTextArea;
    @FXML private TextArea translatedTextArea;
    @FXML private Button translateButton;
    @FXML private ProgressIndicator progress;

    private TextTranslateViewModel viewModel;

    @FXML
    public void initialize() {
        String defaultServer = "http://localhost:8082";
        serverUrlField.setText(defaultServer);

        BackendTranslationClient client = new BackendTranslationClient(defaultServer);
        this.viewModel = new TextTranslateViewModel(client);

        // Language code to full name mapping
        Map<String, String> languageNames = new HashMap<>();
        languageNames.put("auto", "Auto Detect");
        languageNames.put("en", "English");
        languageNames.put("es", "Spanish");
        languageNames.put("fr", "French");
        languageNames.put("de", "German");
        languageNames.put("it", "Italian");
        languageNames.put("pt", "Portuguese");
        languageNames.put("ru", "Russian");
        languageNames.put("zh", "Chinese (Simplified)");
        languageNames.put("zh-cn", "Chinese (Simplified)");
        languageNames.put("ja", "Japanese");
        languageNames.put("ko", "Korean");
        languageNames.put("ar", "Arabic");
        languageNames.put("sv", "Swedish");
        languageNames.put("no", "Norwegian");
        languageNames.put("da", "Danish");
        languageNames.put("fi", "Finnish");
        languageNames.put("nl", "Dutch");
        languageNames.put("pl", "Polish");
        languageNames.put("tr", "Turkish");
        languageNames.put("cs", "Czech");
        languageNames.put("hu", "Hungarian");
        languageNames.put("ro", "Romanian");
        languageNames.put("bg", "Bulgarian");
        languageNames.put("hr", "Croatian");
        languageNames.put("sk", "Slovak");
        languageNames.put("sl", "Slovenian");
        languageNames.put("et", "Estonian");
        languageNames.put("lv", "Latvian");
        languageNames.put("lt", "Lithuanian");
        languageNames.put("uk", "Ukrainian");
        languageNames.put("el", "Greek");
        languageNames.put("he", "Hebrew");
        languageNames.put("hi", "Hindi");
        languageNames.put("th", "Thai");
        languageNames.put("vi", "Vietnamese");
        languageNames.put("id", "Indonesian");
        languageNames.put("ms", "Malay");
        languageNames.put("ta", "Tamil");
        languageNames.put("ml", "Malayalam");
        languageNames.put("kn", "Kannada");
        languageNames.put("gu", "Gujarati");
        languageNames.put("pa", "Punjabi");
        languageNames.put("mr", "Marathi");
        languageNames.put("bn", "Bengali");
        languageNames.put("ur", "Urdu");
        languageNames.put("fa", "Persian (Farsi)");

        // Create reverse mapping for converting full names back to codes
        Map<String, String> nameToCode = new HashMap<>();
        for (Map.Entry<String, String> entry : languageNames.entrySet()) {
            nameToCode.put(entry.getValue(), entry.getKey());
        }

        // Populate language dropdowns with full names
        List<String> sourceCodes = Arrays.asList(
            "auto", "en", "es", "fr", "de", "it", "pt", "ru", "zh", "zh-cn", "ja", "ko", "ar",
            "sv", "no", "da", "fi", "nl", "pl", "tr", "cs", "hu", "ro", "bg", "hr", "sk", "sl", "et", "lv", "lt",
            "uk", "el", "he", "hi", "th", "vi", "id", "ms", "ta", "ml", "kn", "gu", "pa", "mr", "bn", "ur", "fa"
        );
        
        List<String> targetCodes = Arrays.asList(
            "en", "es", "fr", "de", "it", "pt", "ru", "zh", "zh-cn", "ja", "ko", "ar",
            "sv", "no", "da", "fi", "nl", "pl", "tr", "cs", "hu", "ro", "bg", "hr", "sk", "sl", "et", "lv", "lt",
            "uk", "el", "he", "hi", "th", "vi", "id", "ms", "ta", "ml", "kn", "gu", "pa", "mr", "bn", "ur", "fa"
        );

        sourceLangComboBox.setItems(FXCollections.observableArrayList(
            sourceCodes.stream().map(code -> languageNames.getOrDefault(code, code)).collect(Collectors.toList())
        ));
        targetLangComboBox.setItems(FXCollections.observableArrayList(
            targetCodes.stream().map(code -> languageNames.getOrDefault(code, code)).collect(Collectors.toList())
        ));

        // Set default values
        sourceLangComboBox.setValue("Auto Detect");
        targetLangComboBox.setValue("French");

        // Bind ComboBox selections to ViewModel
        sourceLangComboBox.valueProperty().bindBidirectional(viewModel.sourceLangProperty());
        targetLangComboBox.valueProperty().bindBidirectional(viewModel.targetLangProperty());
        sourceTextArea.textProperty().bindBidirectional(viewModel.sourceTextProperty());
        
        // Fix UI binding for translated text
        translatedTextArea.textProperty().bind(viewModel.translatedTextProperty());
        viewModel.translatedTextProperty().addListener((obs, oldVal, newVal) -> {
            System.out.println("DEBUG: Translated text property changed: '" + oldVal + "' -> '" + newVal + "'");
            System.out.println("DEBUG: TextArea text is now: '" + translatedTextArea.getText() + "'");
        });

        progress.visibleProperty().bind(viewModel.busyProperty());
        translateButton.disableProperty().bind(viewModel.busyProperty());
    }

    @FXML
    private void onTranslate() {
        System.out.println("DEBUG: Translate button clicked");
        System.out.println("DEBUG: Source text: '" + sourceTextArea.getText() + "'");
        System.out.println("DEBUG: Source lang: " + sourceLangComboBox.getValue());
        System.out.println("DEBUG: Target lang: " + targetLangComboBox.getValue());
        System.out.println("DEBUG: ViewModel source text: '" + viewModel.sourceTextProperty().get() + "'");
        System.out.println("DEBUG: ViewModel translated text before: '" + viewModel.translatedTextProperty().get() + "'");
        
        viewModel.translate();
        
        System.out.println("DEBUG: ViewModel translated text after: '" + viewModel.translatedTextProperty().get() + "'");
    }

    @FXML
    private void onApplyServerUrl() {
        String baseUrl = serverUrlField.getText().trim();
        BackendTranslationClient client = new BackendTranslationClient(baseUrl);
        this.viewModel = new TextTranslateViewModel(client);

        // Rebind everything to new ViewModel
        sourceLangComboBox.valueProperty().bindBidirectional(viewModel.sourceLangProperty());
        targetLangComboBox.valueProperty().bindBidirectional(viewModel.targetLangProperty());
        sourceTextArea.textProperty().bindBidirectional(viewModel.sourceTextProperty());
        translatedTextArea.textProperty().bind(viewModel.translatedTextProperty());
        progress.visibleProperty().bind(viewModel.busyProperty());
        translateButton.disableProperty().bind(viewModel.busyProperty());
    }
}
