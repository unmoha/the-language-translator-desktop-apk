package com.example.translate.client;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class TranslateClientApp extends Application {

    @Override
    public void start(Stage primaryStage) throws IOException {
        // Load modern UI
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/ModernTranslationView.fxml"));
        Parent root = loader.load();
        
        Scene scene = new Scene(root, 1200, 800);
        
        // Apply modern styling
        scene.getStylesheets().add(getClass().getResource("/styles/modern-translation-ui.css").toExternalForm());
        
        primaryStage.setTitle("GlobalTranslate - Modern Translation App");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(1100);
        primaryStage.setMinHeight(760);
        primaryStage.setMaximized(true);
        primaryStage.show();
        
        // Center window on screen
        primaryStage.centerOnScreen();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
