package com.example.translate.client.voice;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.concurrent.Task;

import javax.sound.sampled.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GeminiVoiceService {

    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient client = HttpClient.newHttpClient();

    public Task<String> transcribeAudio(byte[] wavBytes) {
        return new Task<>() {
            @Override
            protected String call() {
                String key = System.getenv("GEMINI_API_KEY");
                if (key == null || key.isBlank()) {
                    System.out.println("GEMINI_API_KEY not set");
                    return "[Voice input requires Gemini API key]";
                }

                try {
                    String base64 = Base64.getEncoder().encodeToString(wavBytes);
                    String url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-8b:generateContent?key=" + key;

                    Map<String, Object> inlineData = new HashMap<>();
                    inlineData.put("mime_type", "audio/wav");
                    inlineData.put("data", base64);

                    Map<String, Object> part = new HashMap<>();
                    part.put("inline_data", inlineData);

                    Map<String, Object> content = new HashMap<>();
                    content.put("parts", List.of(part));

                    Map<String, Object> body = new HashMap<>();
                    body.put("contents", List.of(content));

                    HttpRequest request = HttpRequest.newBuilder()
                            .uri(URI.create(url))
                            .header("Content-Type", "application/json")
                            .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(body)))
                            .build();

                    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                    if (response.statusCode() != 200) {
                        System.out.println("Gemini voice error: " + response.body());
                        return "[Gemini voice error]";
                    }

                    JsonNode node = mapper.readTree(response.body());
                    JsonNode candidates = node.get("candidates");
                    if (candidates != null && candidates.isArray() && candidates.size() > 0) {
                        JsonNode parts = candidates.get(0).path("content").path("parts");
                        if (parts.isArray() && parts.size() > 0) {
                            String out = parts.get(0).path("text").asText(null);
                            if (out != null && !out.isBlank()) {
                                return out.trim();
                            }
                        }
                    }

                    return "[No transcript]";
                } catch (Exception e) {
                    System.out.println("Gemini voice transcription failed: " + e.getMessage());
                    return "[Voice transcription failed]";
                }
            }
        };
    }

    public byte[] recordWav(int seconds) throws IOException {
        AudioFormat format = new AudioFormat(16000, 16, 1, true, false);
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
        try (TargetDataLine line = (TargetDataLine) AudioSystem.getLine(info);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            line.open(format);
            line.start();
            byte[] buffer = new byte[(int) (format.getFrameSize() * format.getFrameRate() * seconds)];
            int bytesRead = line.read(buffer, 0, buffer.length);
            line.stop();
            line.close();

            // Write WAV header
            int dataLength = bytesRead;
            long totalLength = dataLength + 36;
            out.write("RIFF".getBytes());
            out.write(intToByteArray((int) totalLength));
            out.write("WAVE".getBytes());
            out.write("fmt ".getBytes());
            out.write(intToByteArray(16));
            out.write(shortToByteArray((short) format.getChannels()));
            out.write(intToByteArray((int) format.getSampleRate()));
            out.write(intToByteArray((int) (format.getSampleRate() * format.getChannels() * format.getSampleSizeInBits() / 8)));
            out.write(shortToByteArray((short) (format.getChannels() * format.getSampleSizeInBits() / 8)));
            out.write(shortToByteArray((short) format.getSampleSizeInBits()));
            out.write("data".getBytes());
            out.write(intToByteArray(dataLength));
            out.write(buffer, 0, dataLength);
            return out.toByteArray();
        } catch (LineUnavailableException e) {
            throw new IOException("Microphone not available", e);
        }
    }

    private byte[] intToByteArray(int value) {
        return new byte[] {
                (byte) (value >>> 0),
                (byte) (value >>> 8),
                (byte) (value >>> 16),
                (byte) (value >>> 24)
        };
    }

    private byte[] shortToByteArray(short value) {
        return new byte[] {
                (byte) (value >>> 0),
                (byte) (value >>> 8)
        };
    }
}
