package com.example.translate.client.viewmodel;

import com.example.translate.client.service.BackendTranslationClient;
import com.example.translate.common.dto.TextTranslationRequest;
import com.example.translate.common.dto.TextTranslationResponse;
import javafx.application.Platform;
import javafx.beans.property.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ModernTranslationViewModel {

    private final BackendTranslationClient backendClient;
    
    // Properties
    private final StringProperty sourceText = new SimpleStringProperty();
    private final StringProperty translatedText = new SimpleStringProperty();
    private final StringProperty sourceLanguage = new SimpleStringProperty();
    private final StringProperty targetLanguage = new SimpleStringProperty();
    private final BooleanProperty busy = new SimpleBooleanProperty();
    private final StringProperty errorMessage = new SimpleStringProperty();
    
    // Language mappings
    private final Map<String, String> languageToCode = new LinkedHashMap<>();
    private final Map<String, String> codeToLanguage = new LinkedHashMap<>();
    private final Map<String, String> languageFlags = new LinkedHashMap<>();

    public ModernTranslationViewModel() {
        this.backendClient = new BackendTranslationClient("http://localhost:8082");
        initializeLanguageMappings();

        // Defaults must be set before UI binds bidirectionally, otherwise ComboBoxes can go blank.
        if (languageToCode.containsKey("English")) {
            sourceLanguage.set("English");
        } else {
            sourceLanguage.set(languageToCode.keySet().stream().findFirst().orElse("Auto Detect"));
        }

        if (languageToCode.containsKey("Spanish")) {
            targetLanguage.set("Spanish");
        } else {
            targetLanguage.set(
                languageToCode.keySet().stream()
                    .filter(k -> !"Auto Detect".equals(k))
                    .findFirst()
                    .orElse(sourceLanguage.get())
            );
        }
    }

    private void initializeLanguageMappings() {
        // Language mappings with flags - using LinkedHashMap for stable ordering
        Map<String, String[]> languages = new LinkedHashMap<>();
        languages.put("Auto Detect", new String[]{"auto", "✨"});
        languages.put("English", new String[]{"en", "🇺🇸"});
        languages.put("Spanish", new String[]{"es", "🇪🇸"});
        languages.put("French", new String[]{"fr", "🇫🇷"});
        languages.put("German", new String[]{"de", "🇩🇪"});
        languages.put("Italian", new String[]{"it", "🇮🇹"});
        languages.put("Portuguese", new String[]{"pt", "🇵🇹"});
        languages.put("Russian", new String[]{"ru", "🇷🇺"});
        languages.put("Chinese (Simplified)", new String[]{"zh-CN", "🇨🇳"});
        languages.put("Chinese (Traditional)", new String[]{"zh-TW", "🇹🇼"});
        languages.put("Japanese", new String[]{"ja", "🇯🇵"});
        languages.put("Korean", new String[]{"ko", "🇰🇷"});
        languages.put("Arabic", new String[]{"ar", "🇸🇦"});
        languages.put("Hindi", new String[]{"hi", "🇮🇳"});
        languages.put("Dutch", new String[]{"nl", "🇳🇱"});
        languages.put("Swedish", new String[]{"sv", "🇸🇪"});
        languages.put("Norwegian", new String[]{"no", "🇳🇴"});
        languages.put("Danish", new String[]{"da", "🇩🇰"});
        languages.put("Finnish", new String[]{"fi", "🇫🇮"});
        languages.put("Polish", new String[]{"pl", "🇵🇱"});
        languages.put("Turkish", new String[]{"tr", "🇹🇷"});
        languages.put("Greek", new String[]{"el", "🇬🇷"});
        languages.put("Hebrew", new String[]{"he", "🇮🇱"});
        languages.put("Thai", new String[]{"th", "🇹🇭"});
        languages.put("Vietnamese", new String[]{"vi", "🇻🇳"});
        languages.put("Indonesian", new String[]{"id", "🇮🇩"});
        languages.put("Malay", new String[]{"ms", "🇲🇾"});
        languages.put("Filipino", new String[]{"tl", "🇵🇭"});
        languages.put("Ukrainian", new String[]{"uk", "🇺🇦"});
        languages.put("Czech", new String[]{"cs", "🇨🇿"});
        languages.put("Hungarian", new String[]{"hu", "🇭🇺"});
        languages.put("Romanian", new String[]{"ro", "🇷🇴"});
        languages.put("Bulgarian", new String[]{"bg", "🇧🇬"});
        languages.put("Croatian", new String[]{"hr", "🇭🇷"});
        languages.put("Serbian", new String[]{"sr", "🇷🇸"});
        languages.put("Slovak", new String[]{"sk", "🇸🇰"});
        languages.put("Estonian", new String[]{"et", "🇪🇪"});
        languages.put("Latvian", new String[]{"lv", "🇱🇻"});
        languages.put("Lithuanian", new String[]{"lt", "🇱🇹"});
        languages.put("Slovenian", new String[]{"sl", "🇸🇮"});
        languages.put("Icelandic", new String[]{"is", "🇮🇸"});
        languages.put("Irish", new String[]{"ga", "🇮🇪"});
        languages.put("Scottish Gaelic", new String[]{"gd", "🏴󐁧󐁢󐁳󐁣󐁴󐁿"});
        languages.put("Welsh", new String[]{"cy", "🏴󐁧󐁢󐁷󐁬󐁿󐁲"});
        languages.put("Basque", new String[]{"eu", "🏴󐁧󐁢󐁤󐁮󐁯󐁿"});
        languages.put("Catalan", new String[]{"ca", "🏴󐁧󐁢󐁴󐁮󐁯󐁿"});
        languages.put("Galician", new String[]{"gl", "🏴󐁧󐁢󐁱󐁲󐁿󐁲"});
        languages.put("Esperanto", new String[]{"eo", "🌍"});
        languages.put("Latin", new String[]{"la", "🏛️"});
        languages.put("Afrikaans", new String[]{"af", "🇿🇦"});
        languages.put("Swahili", new String[]{"sw", "🇰🇪"});
        languages.put("Yoruba", new String[]{"yo", "🇳🇬"});
        languages.put("Igbo", new String[]{"ig", "🇳🇬"});
        languages.put("Zulu", new String[]{"zu", "🇿🇦"});

        for (Map.Entry<String, String[]> entry : languages.entrySet()) {
            String language = entry.getKey();
            String code = entry.getValue()[0];
            String flag = entry.getValue()[1];
            
            languageToCode.put(language, code);
            codeToLanguage.put(code, language);
            languageFlags.put(language, flag);
        }
    }

    public void translate() {
        String source = sourceText.get();
        String sourceLang = languageToCode.getOrDefault(sourceLanguage.get(), "auto");
        String targetLang = languageToCode.get(targetLanguage.get());

        if (source == null || source.trim().isEmpty()) {
            return;
        }

        if (targetLang == null || targetLang.isBlank()) {
            errorMessage.set("Please select a target language");
            return;
        }

        busy.set(true);
        errorMessage.set("");
        translatedText.set("");

        new Thread(() -> {
            try {
                TextTranslationRequest request = new TextTranslationRequest();
                request.setSourceText(source);
                request.setSourceLang(sourceLang);
                request.setTargetLang(targetLang);
                request.setDomain("general");
                request.setClientId("modern-ui");

                TextTranslationResponse response = backendClient.translateText(request);

                Platform.runLater(() -> {
                    translatedText.set(response.getTranslatedText());
                    busy.set(false);
                });

            } catch (Exception e) {
                Platform.runLater(() -> {
                    errorMessage.set("Translation failed: " + e.getMessage());
                    busy.set(false);
                });
            }
        }).start();
    }

    public void swapLanguages() {
        String currentSource = sourceLanguage.get();
        String currentTarget = targetLanguage.get();
        String currentText = sourceText.get();
        String currentTranslation = translatedText.get();

        sourceLanguage.set(currentTarget);
        targetLanguage.set(currentSource);
        sourceText.set(currentTranslation);
        translatedText.set(currentText);
    }

    public void speakText(String text) {
        if (text == null || text.isBlank()) {
            return;
        }

        try {
            String safeText = text.replace("'", "''");
            String command = "Add-Type -AssemblyName System.Speech; " +
                    "$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; " +
                    "$speak.Speak('" + safeText + "');";

            new ProcessBuilder(
                    "powershell",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-Command",
                    command
            ).start();
        } catch (Exception e) {
            errorMessage.set("Speak not available: " + e.getMessage());
        }
    }

    public void saveTranslation() {
        String source = sourceText.get();
        String translation = translatedText.get();
        String sourceLang = sourceLanguage.get();
        String targetLang = targetLanguage.get();

        if (source != null && !source.isEmpty() && translation != null && !translation.isEmpty()) {
            try {
                Path dir = Path.of(System.getProperty("user.home"), "GlobalTranslate");
                Files.createDirectories(dir);
                Path file = dir.resolve("history.txt");

                String record = "[" + OffsetDateTime.now() + "] " +
                        (sourceLang == null ? "" : sourceLang) + " -> " + (targetLang == null ? "" : targetLang) + System.lineSeparator() +
                        "SOURCE: " + source + System.lineSeparator() +
                        "TRANSLATION: " + translation + System.lineSeparator() +
                        "---" + System.lineSeparator();

                Files.writeString(
                        file,
                        record,
                        StandardCharsets.UTF_8,
                        StandardOpenOption.CREATE,
                        StandardOpenOption.APPEND
                );
            } catch (IOException e) {
                errorMessage.set("Save failed: " + e.getMessage());
            }
        }
    }

    // Getters for properties
    public StringProperty sourceTextProperty() { return sourceText; }
    public StringProperty translatedTextProperty() { return translatedText; }
    public StringProperty sourceLanguageProperty() { return sourceLanguage; }
    public StringProperty targetLanguageProperty() { return targetLanguage; }
    public BooleanProperty busyProperty() { return busy; }
    public StringProperty errorMessageProperty() { return errorMessage; }

    // Convenience setters
    public void setSourceText(String value) { sourceText.set(value); }
    public void setTranslatedText(String value) { translatedText.set(value); }
    public void setSourceLanguage(String value) { sourceLanguage.set(value); }
    public void setTargetLanguage(String value) { targetLanguage.set(value); }

    // Getters for language data
    public Map<String, String> getSupportedLanguages() {
        return new LinkedHashMap<>(languageToCode);
    }

    public String getLanguageFlag(String language) {
        return languageFlags.getOrDefault(language, "🌐");
    }

    public String getLanguageCode(String language) {
        return languageToCode.getOrDefault(language, "");
    }

    public List<String> getRecentTranslations() {
        // TODO: Implement recent translations
        return List.of();
    }

    public void clearHistory() {
        // TODO: Clear translation history
    }
}
