package com.example.translate.client.service;

import com.example.translate.common.dto.TextTranslationRequest;
import com.example.translate.common.dto.TextTranslationResponse;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class BackendTranslationClient {

    private final HttpClient httpClient;
    private final ObjectMapper mapper;
    private final String baseUrl;

    public BackendTranslationClient(String baseUrl) {
        this.baseUrl = baseUrl;
        this.httpClient = HttpClient.newHttpClient();
        this.mapper = new ObjectMapper();
    }

    public TextTranslationResponse translateText(TextTranslationRequest request) {
        try {
            String json = mapper.writeValueAsString(request);
            System.out.println("DEBUG: Sending JSON: " + json);
            System.out.println("DEBUG: URL: " + baseUrl + "/api/v1/translate/text");
            
            HttpRequest httpRequest = HttpRequest.newBuilder()
                    .uri(URI.create(baseUrl + "/api/v1/translate/text"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(json))
                    .build();

            HttpResponse<String> response =
                    httpClient.send(httpRequest, HttpResponse.BodyHandlers.ofString());

            System.out.println("DEBUG: Response status: " + response.statusCode());
            System.out.println("DEBUG: Response body: " + response.body());

            if (response.statusCode() != 200) {
                throw new RuntimeException("Translation failed: " + response.body());
            }

            return mapper.readValue(response.body(), TextTranslationResponse.class);
        } catch (IOException | InterruptedException e) {
            System.out.println("DEBUG: Exception: " + e.getMessage());
            e.printStackTrace();
            throw new RuntimeException("Error calling backend", e);
        }
    }
}
