package com.example.translate.client.viewmodel;

import com.example.translate.client.service.BackendTranslationClient;
import com.example.translate.common.dto.TextTranslationRequest;
import com.example.translate.common.dto.TextTranslationResponse;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.util.HashMap;
import java.util.Map;

public class TextTranslateViewModel {

    private final BackendTranslationClient backendClient;

    private final StringProperty sourceText = new SimpleStringProperty();
    private final StringProperty translatedText = new SimpleStringProperty();
    private final StringProperty sourceLang = new SimpleStringProperty("auto");
    private final StringProperty targetLang = new SimpleStringProperty("en");
    private final BooleanProperty busy = new SimpleBooleanProperty(false);

    public TextTranslateViewModel(BackendTranslationClient backendClient) {
        this.backendClient = backendClient;
    }

    public void translate() {
        busy.set(true);

        TextTranslationRequest req = new TextTranslationRequest();
        req.setSourceText(sourceText.get());
        
        // Convert full language names back to codes for the API
        String sourceLangCode = convertLanguageNameToCode(sourceLang.get());
        String targetLangCode = convertLanguageNameToCode(targetLang.get());
        
        System.out.println("DEBUG: Source text: " + sourceText.get());
        System.out.println("DEBUG: Source lang: " + sourceLang.get() + " -> " + sourceLangCode);
        System.out.println("DEBUG: Target lang: " + targetLang.get() + " -> " + targetLangCode);
        
        req.setSourceLang(sourceLangCode);
        req.setTargetLang(targetLangCode);

        new Thread(() -> {
            try {
                System.out.println("DEBUG: Sending request to backend...");
                TextTranslationResponse resp = backendClient.translateText(req);
                System.out.println("DEBUG: Response received: " + resp.getTranslatedText());
                Platform.runLater(() -> {
                    translatedText.set(resp.getTranslatedText());
                    System.out.println("DEBUG: UI updated with: " + resp.getTranslatedText());
                });
            } catch (Exception e) {
                System.out.println("DEBUG: Translation error: " + e.getMessage());
                e.printStackTrace();
                Platform.runLater(() -> translatedText.set("Error: " + e.getMessage()));
            } finally {
                Platform.runLater(() -> busy.set(false));
            }
        }).start();
    }

    private String convertLanguageNameToCode(String languageName) {
        // Language name to code mapping
        Map<String, String> nameToCode = new HashMap<>();
        nameToCode.put("Auto Detect", "auto");
        nameToCode.put("English", "en");
        nameToCode.put("Spanish", "es");
        nameToCode.put("French", "fr");
        nameToCode.put("German", "de");
        nameToCode.put("Italian", "it");
        nameToCode.put("Portuguese", "pt");
        nameToCode.put("Russian", "ru");
        nameToCode.put("Chinese (Simplified)", "zh");
        nameToCode.put("Japanese", "ja");
        nameToCode.put("Korean", "ko");
        nameToCode.put("Arabic", "ar");
        nameToCode.put("Swedish", "sv");
        nameToCode.put("Norwegian", "no");
        nameToCode.put("Danish", "da");
        nameToCode.put("Finnish", "fi");
        nameToCode.put("Dutch", "nl");
        nameToCode.put("Polish", "pl");
        nameToCode.put("Turkish", "tr");
        nameToCode.put("Czech", "cs");
        nameToCode.put("Hungarian", "hu");
        nameToCode.put("Romanian", "ro");
        nameToCode.put("Bulgarian", "bg");
        nameToCode.put("Croatian", "hr");
        nameToCode.put("Slovak", "sk");
        nameToCode.put("Slovenian", "sl");
        nameToCode.put("Estonian", "et");
        nameToCode.put("Latvian", "lv");
        nameToCode.put("Lithuanian", "lt");
        nameToCode.put("Ukrainian", "uk");
        nameToCode.put("Greek", "el");
        nameToCode.put("Hebrew", "he");
        nameToCode.put("Hindi", "hi");
        nameToCode.put("Thai", "th");
        nameToCode.put("Vietnamese", "vi");
        nameToCode.put("Indonesian", "id");
        nameToCode.put("Malay", "ms");
        nameToCode.put("Tamil", "ta");
        nameToCode.put("Malayalam", "ml");
        nameToCode.put("Kannada", "kn");
        nameToCode.put("Gujarati", "gu");
        nameToCode.put("Punjabi", "pa");
        nameToCode.put("Marathi", "mr");
        nameToCode.put("Bengali", "bn");
        nameToCode.put("Urdu", "ur");
        nameToCode.put("Persian (Farsi)", "fa");
        
        return nameToCode.getOrDefault(languageName, languageName);
    }

    public StringProperty sourceTextProperty() { return sourceText; }
    public StringProperty translatedTextProperty() { return translatedText; }
    public StringProperty sourceLangProperty() { return sourceLang; }
    public StringProperty targetLangProperty() { return targetLang; }
    public BooleanProperty busyProperty() { return busy; }
}
