package com.example.translate.client.view;

import com.example.translate.client.viewmodel.ModernTranslationViewModel;
import com.example.translate.client.voice.SimpleVoiceService;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ModernTranslationViewController {

    @FXML private ComboBox<String> sourceLanguageComboBox;
    @FXML private ComboBox<String> targetLanguageComboBox;
    @FXML private Button swapLanguagesButton;
    @FXML private TextArea sourceTextArea;
    @FXML private TextArea targetTextArea;
    @FXML private Button translateButton;
    @FXML private Button copyButton;
    @FXML private Button speakButton;
    @FXML private Button saveButton;
    @FXML private Button clearButton;
    @FXML private Label statusLabel;
    @FXML private Label offlineStatusLabel;
    @FXML private StackPane mainContainer;
    @FXML private ToggleButton themeToggleButton;
    @FXML private Button settingsButton;
    @FXML private ToggleButton autoDetectToggle;
    @FXML private ToggleButton fastModeToggle;
    @FXML private ToggleButton accurateModeToggle;
    @FXML private StackPane skeletonLoader;

    private ModernTranslationViewModel viewModel;
    private boolean isDarkMode = false;
    private final SimpleVoiceService voiceService = new SimpleVoiceService();

    @FXML
    public void initialize() {
        viewModel = new ModernTranslationViewModel();
        
        setupLanguageSelectors();
        setupTextAreas();
        setupButtons();
        setupBindings();
        setupAnimations();
        setupModeToggles();

        // Ensure visible defaults after bidirectional binding initialization
        Platform.runLater(this::ensureInitialLanguageSelection);

        Platform.runLater(() -> {
            // Apply the theme based on the toggle state (no forced overrides)
            applyTheme(themeToggleButton != null && themeToggleButton.isSelected());
            if (offlineStatusLabel != null) {
                offlineStatusLabel.setText("Offline Mode • Local AI Active");
            }
        });
        
        // Set initial focus
        Platform.runLater(() -> sourceTextArea.requestFocus());
    }

    private void ensureInitialLanguageSelection() {
        if (sourceLanguageComboBox.getValue() == null) {
            String vmValue = viewModel.sourceLanguageProperty().get();
            if (vmValue != null && sourceLanguageComboBox.getItems().contains(vmValue)) {
                sourceLanguageComboBox.getSelectionModel().select(vmValue);
            } else if (!sourceLanguageComboBox.getItems().isEmpty()) {
                sourceLanguageComboBox.getSelectionModel().selectFirst();
            }
        }

        if (targetLanguageComboBox.getValue() == null) {
            String vmValue = viewModel.targetLanguageProperty().get();
            if (vmValue != null && targetLanguageComboBox.getItems().contains(vmValue)) {
                targetLanguageComboBox.getSelectionModel().select(vmValue);
            } else if (!targetLanguageComboBox.getItems().isEmpty()) {
                targetLanguageComboBox.getSelectionModel().selectFirst();
            }
        }
    }

    private void setupLanguageSelectors() {
        // Populate language options with flags
        Map<String, String> languages = viewModel.getSupportedLanguages();

        var sourceItems = new ArrayList<>(languages.keySet());
        var targetItems = new ArrayList<>(languages.keySet());
        targetItems.remove("Auto Detect");

        sourceLanguageComboBox.getItems().setAll(sourceItems);
        targetLanguageComboBox.getItems().setAll(targetItems);
        
        // Set default languages
        if (sourceLanguageComboBox.getItems().contains("English")) {
            sourceLanguageComboBox.getSelectionModel().select("English");
        } else {
            sourceLanguageComboBox.getSelectionModel().selectFirst();
        }
        if (targetLanguageComboBox.getItems().contains("Spanish")) {
            targetLanguageComboBox.getSelectionModel().select("Spanish");
        } else {
            targetLanguageComboBox.getSelectionModel().selectFirst();
        }
        
        // Custom cell factory for language display with flags
        sourceLanguageComboBox.setCellFactory(param -> createLanguageCell());
        targetLanguageComboBox.setCellFactory(param -> createLanguageCell());
        sourceLanguageComboBox.setButtonCell(createLanguageCell());
        targetLanguageComboBox.setButtonCell(createLanguageCell());
    }

    private ListCell<String> createLanguageCell() {
        return new ListCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    setText(null);
                    setGraphic(createLanguageGraphic(item));
                }
            }
        };
    }

    private HBox createLanguageGraphic(String language) {
        Region flag = new Region();
        flag.getStyleClass().add("lang-flag");

        StackPane flagWrapper = new StackPane(flag);
        flagWrapper.setMinSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
        flagWrapper.setPrefSize(Region.USE_COMPUTED_SIZE, Region.USE_COMPUTED_SIZE);

        flag.getStyleClass().add("flag-generic");

        String rawCode = viewModel.getLanguageCode(language);
        String codeValue = (rawCode == null ? "" : rawCode).trim();
        if (codeValue.isEmpty()) {
            codeValue = language.substring(0, Math.min(2, language.length())).toUpperCase();
        } else {
            int dash = codeValue.indexOf('-');
            if (dash > 0) {
                codeValue = codeValue.substring(0, dash);
            }
            codeValue = codeValue.toUpperCase();
            if ("AUTO".equals(codeValue)) {
                codeValue = "AUTO";
            }
            if (codeValue.length() > 3) {
                codeValue = codeValue.substring(0, 3);
            }
        }

        Label code = new Label(codeValue);
        code.getStyleClass().add("lang-code-text");
        flagWrapper.getChildren().add(code);
        StackPane.setAlignment(code, Pos.CENTER);

        Label name = new Label(language);
        HBox box = new HBox(8, flagWrapper, name);
        box.setAlignment(Pos.CENTER_LEFT);
        return box;
    }

    private void setupTextAreas() {
        // Auto-resize text areas based on content
        sourceTextArea.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && newVal.length() > 100) {
                sourceTextArea.setPrefRowCount(6);
            } else {
                sourceTextArea.setPrefRowCount(4);
            }
        });

        targetTextArea.textProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && newVal.length() > 100) {
                targetTextArea.setPrefRowCount(6);
            } else {
                targetTextArea.setPrefRowCount(4);
            }
        });

        // Character count
        sourceTextArea.textProperty().addListener((obs, oldVal, newVal) -> {
            int charCount = newVal != null ? newVal.length() : 0;
            updateStatusLabel(charCount + " characters");
        });
    }

    private void setupButtons() {
        translateButton.setDisable(true);
        
        // Button tooltips
        setupTooltip(swapLanguagesButton, "Swap languages");
        setupTooltip(copyButton, "Copy translation to clipboard");
        setupTooltip(speakButton, "Speak translation");
        setupTooltip(saveButton, "Save translation");
        setupTooltip(clearButton, "Clear all text");
    }

    private void setupTooltip(Control control, String text) {
        Tooltip tooltip = new Tooltip(text);
        tooltip.setStyle("-fx-font-size: 12px; -fx-background-color: #1F2937; -fx-text-fill: white;");
        control.setTooltip(tooltip);
    }

    private void setupBindings() {
        // Bind UI to ViewModel
        sourceTextArea.textProperty().bindBidirectional(viewModel.sourceTextProperty());
        targetTextArea.textProperty().bind(viewModel.translatedTextProperty());
        sourceLanguageComboBox.valueProperty().bindBidirectional(viewModel.sourceLanguageProperty());
        targetLanguageComboBox.valueProperty().bindBidirectional(viewModel.targetLanguageProperty());
        
        translateButton.disableProperty().bind(viewModel.busyProperty().or(sourceTextArea.textProperty().isEmpty()));
        
        // Listen for translation completion
        viewModel.translatedTextProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                animateTranslationReveal();
                updateStatusLabel("Translation completed ✓");
            }
        });
        
        // Listen for errors
        viewModel.errorMessageProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null && !newVal.isEmpty()) {
                updateStatusLabel("Error: " + newVal);
                animateError();
            }
        });
    }

    private void setupAnimations() {
        // Initial fade-in animation
        FadeTransition fadeIn = new FadeTransition(Duration.millis(800), mainContainer);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.play();
    }

    private void setupModeToggles() {
        if (fastModeToggle != null && accurateModeToggle != null) {
            fastModeToggle.setOnAction(e -> setFastMode());
            accurateModeToggle.setOnAction(e -> setAccurateMode());
            // Default to Fast mode
            fastModeToggle.setSelected(true);
        }
    }

    private void showSkeleton(boolean show) {
        if (skeletonLoader != null) {
            skeletonLoader.setVisible(show);
            skeletonLoader.setManaged(show);
            targetTextArea.setVisible(!show);
        }
    }

    @FXML
    private void translate() {
        showSkeleton(true);
        updateStatusLabel("Translating…");
        animateButtonPress(translateButton);

        Task<String> translateTask = new Task<>() {
            @Override
            protected String call() throws Exception {
                viewModel.setSourceText(sourceTextArea.getText());
                viewModel.setSourceLanguage(autoDetectToggle.isSelected() ? "auto" : sourceLanguageComboBox.getValue());
                viewModel.setTargetLanguage(targetLanguageComboBox.getValue());
                viewModel.translate();
                return viewModel.translatedTextProperty().get();
            }
        };

        translateTask.setOnSucceeded(e -> {
            String result = translateTask.getValue();
            targetTextArea.setText(result);
            updateStatusLabel("Done");
            showSkeleton(false);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(400), targetTextArea);
            fadeIn.setFromValue(0.0);
            fadeIn.setToValue(1.0);
            fadeIn.play();
        });

        translateTask.setOnFailed(e -> {
            updateStatusLabel("Translation failed");
            showSkeleton(false);
            animateError();
        });

        new Thread(translateTask).start();
    }

    @FXML
    private void toggleAutoDetect() {
        boolean auto = autoDetectToggle.isSelected();
        if (auto) {
            sourceLanguageComboBox.setDisable(true);
            updateStatusLabel("Auto-detect enabled");
        } else {
            sourceLanguageComboBox.setDisable(false);
            updateStatusLabel("Auto-detect disabled");
        }
    }

    @FXML
    private void setFastMode() {
        fastModeToggle.setSelected(true);
        accurateModeToggle.setSelected(false);
        updateStatusLabel("Fast mode");
    }

    @FXML
    private void setAccurateMode() {
        accurateModeToggle.setSelected(true);
        fastModeToggle.setSelected(false);
        updateStatusLabel("Accurate mode");
    }

    @FXML
    private void swapLanguages() {
        animateSwapLanguages();
        viewModel.swapLanguages();
    }

    @FXML
    private void copyTranslation() {
        String text = targetTextArea.getText();
        if (text != null && !text.isBlank()) {
            ClipboardContent content = new ClipboardContent();
            content.putString(text);
            Clipboard.getSystemClipboard().setContent(content);
            updateStatusLabel("Copied");
        } else {
            updateStatusLabel("Nothing to copy");
        }
    }

    @FXML
    private void speakTranslation() {
        String translation = targetTextArea.getText();
        if (translation != null && !translation.isEmpty()) {
            viewModel.speakText(translation);
            animateButtonPress(speakButton);
            updateStatusLabel("Speaking...");
        }
    }

    @FXML
    private void saveTranslation() {
        viewModel.saveTranslation();
        animateButtonPress(saveButton);
        updateStatusLabel("Translation saved ✓");
    }

    @FXML
    private void clearText() {
        animateClearText();
        sourceTextArea.clear();
        targetTextArea.clear();
        updateStatusLabel("Text cleared");
    }

    @FXML
    private void toggleTheme() {
        applyTheme(themeToggleButton.isSelected());
        
        animateThemeToggle();
        updateStatusLabel(isDarkMode ? "Dark mode" : "Light mode");
    }

    private void applyTheme(boolean dark) {
        isDarkMode = dark;
        if (dark) {
            if (!mainContainer.getStyleClass().contains("dark")) {
                mainContainer.getStyleClass().add("dark");
            }
        } else {
            mainContainer.getStyleClass().remove("dark");
        }
    }

    @FXML
    private void goHome() {
        updateStatusLabel("Home");
    }

    @FXML
    private void openHistory() {
        updateStatusLabel("History coming soon...");
    }

    @FXML
    private void startVoiceInput() {
        updateStatusLabel("Recording...");
        // Disable mic during recording
        Button micButton = (Button) sourceTextArea.lookup(".icon-button");
        if (micButton != null) micButton.setDisable(true);

        Task<byte[]> recordTask = voiceService.recordAudio();

        recordTask.setOnSucceeded(e -> {
            byte[] wav = recordTask.getValue();
            updateStatusLabel("Transcribing...");
            Task<String> transcribeTask = voiceService.transcribeAudio(wav);
            transcribeTask.setOnSucceeded(t -> {
                String transcript = transcribeTask.getValue();
                if (!transcript.startsWith("[") && !transcript.isBlank()) {
                    sourceTextArea.appendText(" " + transcript);
                    updateStatusLabel("Voice added");
                } else {
                    updateStatusLabel(transcript);
                }
                if (micButton != null) micButton.setDisable(false);
            });
            transcribeTask.setOnFailed(t -> {
                updateStatusLabel("[Voice failed]");
                if (micButton != null) micButton.setDisable(false);
            });
            new Thread(transcribeTask).start();
        });

        recordTask.setOnFailed(e -> {
            updateStatusLabel("[Mic error]");
            if (micButton != null) micButton.setDisable(false);
        });

        new Thread(recordTask).start();
    }

    @FXML
    private void openSettings() {
        // TODO: Implement settings dialog
        updateStatusLabel("Settings coming soon...");
    }

    private void updateStatusLabel(String message) {
        statusLabel.setText(message);
        
        // Auto-hide status after 3 seconds
        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(3), e -> {
            if (statusLabel.getText().equals(message)) {
                statusLabel.setText("");
            }
        }));
        timeline.play();
    }

    private void animateButtonPress(Button button) {
        ScaleTransition scaleDown = new ScaleTransition(Duration.millis(100), button);
        scaleDown.setToX(0.95);
        scaleDown.setToY(0.95);
        
        ScaleTransition scaleUp = new ScaleTransition(Duration.millis(100), button);
        scaleUp.setToX(1.0);
        scaleUp.setToY(1.0);
        
        SequentialTransition sequential = new SequentialTransition(scaleDown, scaleUp);
        sequential.play();
    }

    private void animateSwapLanguages() {
        RotateTransition rotate = new RotateTransition(Duration.millis(300), swapLanguagesButton);
        rotate.setByAngle(180);
        rotate.play();
    }

    private void animateTranslationReveal() {
        // Smooth, premium reveal (no spinner): slight rise + fade in
        targetTextArea.setOpacity(0.0);
        targetTextArea.setTranslateY(2);

        FadeTransition fade = new FadeTransition(Duration.millis(160), targetTextArea);
        fade.setFromValue(0.0);
        fade.setToValue(1.0);

        TranslateTransition rise = new TranslateTransition(Duration.millis(160), targetTextArea);
        rise.setFromY(2);
        rise.setToY(0);
        rise.setInterpolator(Interpolator.EASE_OUT);

        ParallelTransition pt = new ParallelTransition(fade, rise);
        pt.play();
    }

    private void animateError() {
        ShakeTransition shake = new ShakeTransition(targetTextArea);
        shake.play();
    }

    private void animateClearText() {
        FadeTransition fadeOut = new FadeTransition(Duration.millis(300), sourceTextArea);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.3);
        
        FadeTransition fadeIn = new FadeTransition(Duration.millis(300), sourceTextArea);
        fadeIn.setFromValue(0.3);
        fadeIn.setToValue(1.0);
        
        SequentialTransition sequential = new SequentialTransition(fadeOut, fadeIn);
        sequential.play();
    }

    private void animateThemeToggle() {
        FadeTransition fade = new FadeTransition(Duration.millis(500), mainContainer);
        fade.setFromValue(1.0);
        fade.setToValue(0.7);
        fade.setAutoReverse(true);
        fade.setCycleCount(2);
        fade.setOnFinished(e -> mainContainer.setOpacity(1.0));
        fade.play();
    }

    // Custom shake animation for errors
    private static class ShakeTransition extends Transition {
        private static final Duration DURATION = Duration.millis(500);
        private final Control node;
        private final double startX;

        public ShakeTransition(Control node) {
            setCycleDuration(DURATION);
            setCycleCount(1);
            this.node = node;
            this.startX = node.getTranslateX();
        }

        @Override
        protected void interpolate(double frac) {
            double offset = Math.sin(frac * Math.PI * 8) * 5 * (1 - frac);
            node.setTranslateX(startX + offset);
        }

        @Override
        public void stop() {
            super.stop();
            node.setTranslateX(startX);
        }
    }
}
