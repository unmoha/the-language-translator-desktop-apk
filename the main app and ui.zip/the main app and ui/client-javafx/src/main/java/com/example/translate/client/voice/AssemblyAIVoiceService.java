package com.example.translate.client.voice;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import javafx.concurrent.Task;

import javax.sound.sampled.*;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AssemblyAIVoiceService {

    private final ObjectMapper mapper = new ObjectMapper();
    private final HttpClient client = HttpClient.newHttpClient();

    public Task<String> transcribeAudio(byte[] wavBytes) {
        return new Task<>() {
            @Override
            protected String call() {
                String key = System.getenv("ASSEMBLYAI_API_KEY");
                if (key == null || key.isBlank()) {
                    System.out.println("ASSEMBLYAI_API_KEY not set");
                    return "[Voice input requires AssemblyAI API key]";
                }

                try {
                    // First upload the audio file
                    String uploadUrl = "https://api.assemblyai.com/v2/upload";
                    
                    // Create temporary file for upload
                    Path tempFile = Files.createTempFile("voice", ".wav");
                    Files.write(tempFile, wavBytes);
                    
                    // Upload audio file
                    HttpRequest uploadRequest = HttpRequest.newBuilder()
                        .uri(URI.create(uploadUrl))
                        .header("Authorization", key)
                        .POST(HttpRequest.BodyPublishers.ofFile(tempFile))
                        .build();
                    
                    HttpResponse<String> uploadResponse = client.send(uploadRequest, 
                        HttpResponse.BodyHandlers.ofString());
                    
                    // Clean up temp file
                    Files.deleteIfExists(tempFile);
                    
                    if (uploadResponse.statusCode() != 200) {
                        System.out.println("AssemblyAI upload failed: " + uploadResponse.body());
                        return "[Voice upload failed]";
                    }
                    
                    JsonNode uploadResult = mapper.readTree(uploadResponse.body());
                    String audioUrl = uploadResult.get("upload_url").asText();
                    
                    // Start transcription
                    String transcriptUrl = "https://api.assemblyai.com/v2/transcript";
                    
                    Map<String, Object> transcriptBody = new HashMap<>();
                    transcriptBody.put("audio_url", audioUrl);
                    transcriptBody.put("language_detection", true);
                    
                    HttpRequest transcriptRequest = HttpRequest.newBuilder()
                        .uri(URI.create(transcriptUrl))
                        .header("Authorization", key)
                        .header("Content-Type", "application/json")
                        .POST(HttpRequest.BodyPublishers.ofString(mapper.writeValueAsString(transcriptBody)))
                        .build();
                    
                    HttpResponse<String> transcriptResponse = client.send(transcriptRequest, 
                        HttpResponse.BodyHandlers.ofString());
                    
                    if (transcriptResponse.statusCode() != 200) {
                        System.out.println("AssemblyAI transcript request failed: " + transcriptResponse.body());
                        return "[Transcription request failed]";
                    }
                    
                    JsonNode transcriptResult = mapper.readTree(transcriptResponse.body());
                    String transcriptId = transcriptResult.get("id").asText();
                    
                    // Poll for completion
                    String pollUrl = "https://api.assemblyai.com/v2/transcript/" + transcriptId;
                    
                    while (true) {
                        HttpRequest pollRequest = HttpRequest.newBuilder()
                            .uri(URI.create(pollUrl))
                            .header("Authorization", key)
                            .GET()
                            .build();
                        
                        HttpResponse<String> pollResponse = client.send(pollRequest, 
                            HttpResponse.BodyHandlers.ofString());
                        
                        JsonNode pollResult = mapper.readTree(pollResponse.body());
                        String status = pollResult.get("status").asText();
                        
                        if ("completed".equals(status)) {
                            String text = pollResult.get("text").asText();
                            return text.isEmpty() ? "[No speech detected]" : text.trim();
                        } else if ("error".equals(status)) {
                            String error = pollResult.get("error").asText();
                            System.out.println("AssemblyAI transcription error: " + error);
                            return "[Transcription error: " + error + "]";
                        }
                        
                        // Wait before polling again
                        Thread.sleep(1000);
                    }
                    
                } catch (Exception e) {
                    System.out.println("AssemblyAI voice error: " + e.getMessage());
                    return "[Voice transcription failed]";
                }
            }
        };
    }

    public Task<byte[]> recordAudio() {
        return new Task<>() {
            @Override
            protected byte[] call() throws Exception {
                AudioFormat format = new AudioFormat(16000, 16, 1, true, false);
                DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
                
                if (!AudioSystem.isLineSupported(info)) {
                    throw new RuntimeException("Microphone not supported");
                }
                
                TargetDataLine line = (TargetDataLine) AudioSystem.getLine(info);
                line.open(format);
                line.start();
                
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096];
                long startTime = System.currentTimeMillis();
                
                // Record for 5 seconds
                while (System.currentTimeMillis() - startTime < 5000) {
                    int bytesRead = line.read(buffer, 0, buffer.length);
                    out.write(buffer, 0, bytesRead);
                }
                
                line.stop();
                line.close();
                
                return out.toByteArray();
            }
        };
    }
}
